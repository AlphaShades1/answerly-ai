// ── Background Service Worker ────────────────────────────────────────────────
// Responsibilities:
//  1. Route messages between popup and content scripts
//  2. Capture visible tab screenshots (captureVisibleTab requires background)
//  3. Re-inject content scripts on navigation if needed

const BACKEND_URL = 'https://answerly-ai-backend.onrender.com';

// ── Message router ────────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.type) {

    // Content script requests a screenshot capture
    case 'CAPTURE_SCREENSHOT': {
      const tabId = sender.tab?.id;
      if (!tabId) {
        sendResponse({ error: 'No tab ID available' });
        return false;
      }
      chrome.tabs.captureVisibleTab(sender.tab.windowId, { format: 'png' }, (dataUrl) => {
        if (chrome.runtime.lastError) {
          sendResponse({ error: chrome.runtime.lastError.message });
        } else {
          sendResponse({ dataUrl });
        }
      });
      return true; // Keep the message channel open for async response
    }

    // Popup requests the current auth token (forwarded to solve endpoints)
    case 'GET_AUTH_TOKEN': {
      chrome.storage.local.get('answerlySession', (result) => {
        sendResponse({ token: result.answerlySession?.token || null });
      });
      return true;
    }

    // Relay solve-question request from content script through to backend
    case 'SOLVE_QUESTION': {
      chrome.storage.local.get('answerlySession', async (result) => {
        const token = result.answerlySession?.token;
        if (!token) {
          sendResponse({ error: 'Not logged in' });
          return;
        }
        try {
          const res = await fetch(`${BACKEND_URL}/api/solve-question`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${token}`,
            },
            body: JSON.stringify({ question: message.question, options: message.options }),
          });
          const data = await res.json();
          if (!res.ok) {
            sendResponse({ error: data.error || 'Server error', limitReached: data.limitReached });
          } else {
            sendResponse({ hint: data.hint, answer: data.answer });
          }
        } catch (err) {
          sendResponse({ error: 'Network error — is the backend running?' });
        }
      });
      return true;
    }

    // Relay solve-screenshot request from content script through to backend
    case 'SOLVE_SCREENSHOT': {
      chrome.storage.local.get('answerlySession', async (result) => {
        const token = result.answerlySession?.token;
        if (!token) {
          sendResponse({ error: 'Not logged in' });
          return;
        }
        try {
          const res = await fetch(`${BACKEND_URL}/api/solve-screenshot`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${token}`,
            },
            body: JSON.stringify({ image: message.image, context: message.context }),
          });
          const data = await res.json();
          if (!res.ok) {
            sendResponse({ error: data.error || 'Server error', limitReached: data.limitReached });
          } else {
            sendResponse({ response: data.response });
          }
        } catch (err) {
          sendResponse({ error: 'Network error — is the backend running?' });
        }
      });
      return true;
    }
  }
});

// ── Re-inject content scripts after navigation ────────────────────────────────
// Handles SPAs and Canvas's AJAX-heavy quiz navigation
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status !== 'complete') return;
  const url = tab.url || '';
  if (!/instructure\.com\/courses\/\d+\/(quizzes|assignments)/.test(url)) return;

  // Re-apply stored toggle states to the newly loaded page
  chrome.storage.local.get(['answerlyQuizActive', 'answerlyScreenshotActive', 'answerlyStealthActive'], (stored) => {
    if (stored.answerlyQuizActive) {
      chrome.tabs.sendMessage(tabId, { type: 'QUIZ_SOLVER_ON' }).catch(() => {});
    }
    if (stored.answerlyScreenshotActive) {
      chrome.tabs.sendMessage(tabId, { type: 'SCREENSHOT_TOOL_ON' }).catch(() => {});
    }
    if (stored.answerlyStealthActive) {
      chrome.tabs.sendMessage(tabId, { type: 'STEALTH_ON' }).catch(() => {});
    }
  });
});
