// ── Answerly AI — Quiz Solver Content Script ─────────────────────────────────────
if (window.__answerlyQuizSolverLoaded) { /* already running */ } else {
window.__answerlyQuizSolverLoaded = true;

(function () {
  'use strict';

  let solverActive  = false;
  let stealthHidden = false;
  let observer      = null;
  const INJECTED    = 'answerly-injected';

  // ── Styles ─────────────────────────────────────────────────────────────────
  function injectStyles() {
    if (document.getElementById('answerly-styles')) return;
    const s = document.createElement('style');
    s.id = 'answerly-styles';
    s.textContent = `
      /* Trigger button next to question number */
      .answerly-btn {
        display: inline-flex !important;
        align-items: center !important;
        justify-content: center !important;
        width: 26px !important; height: 26px !important;
        border-radius: 50% !important;
        border: none !important;
        background: #7c5cfc !important;
        color: #fff !important;
        cursor: pointer !important;
        margin-left: 8px !important;
        vertical-align: middle !important;
        font-size: 13px !important;
        box-shadow: 0 2px 8px rgba(124,92,252,.5) !important;
        transition: transform .15s, box-shadow .15s !important;
        flex-shrink: 0 !important;
        position: relative !important;
        z-index: 9999 !important;
        line-height: 1 !important;
      }
      .answerly-btn:hover {
        transform: scale(1.12) !important;
        box-shadow: 0 3px 14px rgba(124,92,252,.75) !important;
      }
      .answerly-btn:active { transform: scale(0.95) !important; }

      /* Hint + Answer card */
      .answerly-card {
        margin: 10px 0 !important;
        background: #1a1a2e !important;
        border: 1px solid #3a3a5c !important;
        border-radius: 10px !important;
        padding: 14px 16px !important;
        font-size: 13px !important;
        line-height: 1.55 !important;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif !important;
        animation: answerly-in .2s ease !important;
        box-sizing: border-box !important;
      }
      @keyframes answerly-in {
        from { opacity: 0; transform: translateY(-4px); }
        to   { opacity: 1; transform: translateY(0); }
      }

      .answerly-badge {
        font-size: 10px !important;
        font-weight: 700 !important;
        letter-spacing: .8px !important;
        color: #7c5cfc !important;
        text-transform: uppercase !important;
        margin-bottom: 8px !important;
        display: flex !important;
        align-items: center !important;
        gap: 5px !important;
      }

      /* Hint row */
      .answerly-hint-row {
        color: #c0c0d8 !important;
        margin-bottom: 10px !important;
        font-size: 13px !important;
      }
      .answerly-hint-lbl {
        color: #fff !important;
        font-weight: 700 !important;
        margin-right: 4px !important;
      }

      /* Reveal button */
      .answerly-reveal {
        background: none !important;
        border: 1px solid #4a4a6a !important;
        color: #a090f0 !important;
        font-size: 12px !important;
        font-weight: 600 !important;
        cursor: pointer !important;
        padding: 5px 12px !important;
        border-radius: 6px !important;
        display: inline-flex !important;
        align-items: center !important;
        gap: 5px !important;
        transition: background .15s, border-color .15s !important;
      }
      .answerly-reveal:hover {
        background: rgba(124,92,252,.15) !important;
        border-color: #7c5cfc !important;
        color: #fff !important;
      }

      /* Answer row — white bold on dark */
      .answerly-answer-row {
        margin-top: 10px !important;
        padding: 10px 14px !important;
        background: #0f0f1e !important;
        border: 1px solid #7c5cfc !important;
        border-radius: 8px !important;
        animation: answerly-in .15s ease !important;
      }
      .answerly-answer-lbl {
        font-size: 10px !important;
        font-weight: 700 !important;
        letter-spacing: .8px !important;
        color: #7c5cfc !important;
        text-transform: uppercase !important;
        display: block !important;
        margin-bottom: 4px !important;
      }
      .answerly-answer-text {
        color: #ffffff !important;
        font-weight: 800 !important;
        font-size: 14px !important;
        line-height: 1.4 !important;
      }

      /* Loading */
      .answerly-loading {
        color: #a090f0 !important;
        font-size: 12px !important;
        font-style: italic !important;
        display: flex !important;
        align-items: center !important;
        gap: 7px !important;
      }
      .answerly-spinner {
        width: 12px !important; height: 12px !important;
        border: 2px solid #3a3a5c !important;
        border-top-color: #7c5cfc !important;
        border-radius: 50% !important;
        animation: answerly-spin .65s linear infinite !important;
        flex-shrink: 0 !important;
      }
      @keyframes answerly-spin { to { transform: rotate(360deg); } }

      .answerly-error { color: #f05454 !important; font-size: 12px !important; }
      .answerly-stealth-hidden { visibility: hidden !important; opacity: 0 !important; }
    `;
    document.head.appendChild(s);
  }

  // ── Find questions ─────────────────────────────────────────────────────────
  function findQuestions() {
    const selectors = [
      'div.question.display_question',
      'div[id^="question_"].question',
      '.question_holder > .question',
      'div[data-question-type]',
      '.quiz-question',
    ];
    for (const sel of selectors) {
      const els = Array.from(document.querySelectorAll(sel));
      if (els.length) return els;
    }
    return [];
  }

  function extractData(qEl) {
    const textEl =
      qEl.querySelector('.question_text') ||
      qEl.querySelector('[data-question-text]') ||
      qEl.querySelector('.question-text');
    const questionText = textEl ? textEl.innerText.trim() : '';

    const labelEls = qEl.querySelectorAll('.answer .answer_label, .answer_label, [data-answer-text]');
    const seen = new Set();
    const options = [];
    labelEls.forEach(el => {
      const t = el.innerText.trim();
      if (t && !seen.has(t)) { seen.add(t); options.push(t); }
    });
    return { questionText, options };
  }

  // ── Inject buttons ─────────────────────────────────────────────────────────
  function injectButtons() {
    const questions = findQuestions();
    console.log('[Answerly AI] Found', questions.length, 'question(s)');

    questions.forEach(qEl => {
      if (qEl.querySelector('.answerly-btn')) return; // already injected

      const { questionText, options } = extractData(qEl);
      if (!questionText) return;

      const isFreeText = options.length === 0;

      const header =
        qEl.querySelector('.question_name') ||
        qEl.querySelector('.question-header') ||
        qEl.querySelector('.header') ||
        qEl.firstElementChild;
      if (!header) return;

      // ── Trigger button ────────────────────────────────────────────────────
      const btn = document.createElement('button');
      btn.type      = 'button'; // CRITICAL: prevent form submission
      btn.className = `answerly-btn ${INJECTED}`;
      btn.title     = 'Answerly AI — hint & answer';
      btn.innerHTML = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`;
      header.appendChild(btn);

      // ── Answer card ───────────────────────────────────────────────────────
      const card = document.createElement('div');
      card.className    = `answerly-card ${INJECTED}`;
      card.style.display = 'none';
      card.innerHTML = `
        <div class="answerly-badge">
          <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
          Answerly AI
        </div>
        <div class="answerly-hint-area">
          ${isFreeText
            ? `<div class="answerly-hint-row" style="color:#a090f0!important;">
                📸 This is a free-response question.<br>
                <span style="color:#c0c0d8!important;">Use the <strong style="color:#fff!important;">Screenshot Tool</strong> in the extension for AI assistance.</span>
               </div>`
            : `<div class="answerly-loading"><div class="answerly-spinner"></div>Thinking…</div>`
          }
        </div>`;

      const answers = qEl.querySelector('.answers') || qEl.querySelector('.answer_group');
      (answers || qEl).insertAdjacentElement('afterend', card);

      if (stealthHidden) {
        btn.classList.add('answerly-stealth-hidden');
        card.classList.add('answerly-stealth-hidden');
      }

      btn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        const isOpen = card.style.display !== 'none';
        card.style.display = isOpen ? 'none' : 'block';
        if (!isOpen && !card.dataset.loaded && !isFreeText) {
          fetchAnswer(card, questionText, options);
        }
        if (!isOpen) card.dataset.loaded = 'true';
      });

    });
  }

  // ── API ────────────────────────────────────────────────────────────────────
  function fetchAnswer(card, questionText, options) {
    card.dataset.loaded = 'true';
    chrome.runtime.sendMessage(
      { type: 'SOLVE_QUESTION', question: questionText, options },
      (resp) => {
        if (chrome.runtime.lastError || !resp) {
          return renderError(card, 'Extension error — try reloading.');
        }
        if (resp.error) return renderError(card, resp.error, resp.limitReached);
        renderResult(card, resp.hint, resp.answer);
      }
    );
  }

  function renderResult(card, hint, answer) {
    const area = card.querySelector('.answerly-hint-area');
    area.innerHTML = `
      <div class="answerly-hint-row">
        <span class="answerly-hint-lbl">Hint: </span>${esc(hint)}
      </div>
      <button type="button" class="answerly-reveal" data-open="false">
        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"/></svg>
        Show Answer
      </button>`;

    area.querySelector('.answerly-reveal').addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      const open = this.dataset.open === 'true';
      const existing = area.querySelector('.answerly-answer-row');
      if (open) {
        existing?.remove();
        this.innerHTML = `<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"/></svg> Show Answer`;
        this.dataset.open = 'false';
      } else {
        const row = document.createElement('div');
        row.className = 'answerly-answer-row';
        row.innerHTML = `<span class="answerly-answer-lbl">Answer</span><div class="answerly-answer-text">${esc(answer)}</div>`;
        this.insertAdjacentElement('afterend', row);
        this.innerHTML = `<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" style="transform:rotate(90deg)"><polyline points="9 18 15 12 9 6"/></svg> Hide Answer`;
        this.dataset.open = 'true';
      }
    });
  }

  function renderError(card, msg, limitReached) {
    card.querySelector('.answerly-hint-area').innerHTML =
      `<div class="answerly-error">${esc(msg)}${limitReached
        ? ' <a href="https://your-site.com/billing" target="_blank" style="color:#7c5cfc;text-decoration:underline">Upgrade →</a>'
        : ''}</div>`;
  }

  function esc(s) {
    return String(s)
      .replace(/&/g,'&amp;')
      .replace(/</g,'&lt;')
      .replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;');
  }

  // ── Cleanup ────────────────────────────────────────────────────────────────
  function removeAll() {
    document.querySelectorAll(`.${INJECTED}`).forEach(el => el.remove());
    observer?.disconnect();
    observer = null;
  }

  function startObserver() {
    if (observer) return;
    observer = new MutationObserver(() => { if (solverActive) injectButtons(); });
    observer.observe(document.body, { childList: true, subtree: true });
  }

  function applyStealthState(hidden) {
    stealthHidden = hidden;
    document.querySelectorAll(`.${INJECTED}`)
      .forEach(el => el.classList.toggle('answerly-stealth-hidden', hidden));
  }

  function activate()   { solverActive = true;  injectStyles(); injectButtons(); startObserver(); }
  function deactivate() { solverActive = false;  removeAll(); }

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'QUIZ_SOLVER_ON')  activate();
    if (msg.type === 'QUIZ_SOLVER_OFF') deactivate();
    if (msg.type === 'STEALTH_ON')  applyStealthState(true);
    if (msg.type === 'STEALTH_OFF') applyStealthState(false);
  });

  chrome.storage.local.get(['answerlyQuizActive', 'answerlyStealthActive'], (s) => {
    if (s.answerlyStealthActive) stealthHidden = true;
    if (s.answerlyQuizActive)    activate();
  });

})();
} // end guard
