// ── Config ────────────────────────────────────────────────────────────────────
const BACKEND_URL = 'https://answerly-ai-backend.onrender.com';

// ── State ─────────────────────────────────────────────────────────────────────
let currentSession   = null; // { token, code, expiresAt }
let quizActive       = false;
let screenshotActive = false;
let stealthActive    = false;

// ── DOM refs ──────────────────────────────────────────────────────────────────
const viewActivate = document.getElementById('view-activate');
const viewMain     = document.getElementById('view-main');

const codeInput      = document.getElementById('code-input');
const activateError  = document.getElementById('activate-error');
const btnActivate    = document.getElementById('btn-activate');
const btnBuy         = document.getElementById('btn-buy');

const btnProfile      = document.getElementById('btn-profile');
const profileDropdown = document.getElementById('profile-dropdown');
const profileCode     = document.getElementById('profile-code');
const profileExpiry   = document.getElementById('profile-expiry');
const btnDeactivate   = document.getElementById('btn-deactivate');

const btnMenu      = document.getElementById('btn-menu');
const menuDropdown = document.getElementById('menu-dropdown');
const btnClose     = document.getElementById('btn-close');

const notCanvasNotice = document.getElementById('not-canvas-notice');
const btnQuizSolver   = document.getElementById('btn-quiz-solver');
const quizLabel       = document.getElementById('quiz-label');
const btnScreenshot   = document.getElementById('btn-screenshot');
const screenshotLabel = document.getElementById('screenshot-label');

const btnStealth          = document.getElementById('btn-stealth');
const stealthEyeIcon      = document.getElementById('stealth-eye-icon');
const stealthEyeSlashIcon = document.getElementById('stealth-eye-slash-icon');

// ── Helpers ───────────────────────────────────────────────────────────────────
function showView(id) {
  [viewActivate, viewMain].forEach(v => v.classList.add('hidden'));
  document.getElementById(id).classList.remove('hidden');
}

function formatCode(raw) {
  // Strip everything except alphanumeric, uppercase
  let clean = raw.toUpperCase().replace(/[^A-Z0-9]/g, '');
  // Remove leading ANS prefix if user typed it
  if (clean.startsWith('ANS')) clean = clean.slice(3);
  // Chunk into groups of 4
  const chunks = clean.match(/.{1,4}/g) || [];
  return 'ANS-' + chunks.slice(0, 3).join('-');
}

function formatDate(iso) {
  return new Date(iso).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
}

// ── Init ──────────────────────────────────────────────────────────────────────
async function init() {
  const stored = await chrome.storage.local.get([
    'answerlySession', 'answerlyQuizActive', 'answerlyScreenshotActive', 'answerlyStealthActive'
  ]);

  if (stored.answerlySession) {
    // Verify the stored token is still valid on the server
    try {
      const res = await fetch(`${BACKEND_URL}/api/auth/verify`, {
        headers: { 'Authorization': `Bearer ${stored.answerlySession.token}` }
      });
      if (res.ok) {
        currentSession   = stored.answerlySession;
        quizActive       = !!stored.answerlyQuizActive;
        screenshotActive = !!stored.answerlyScreenshotActive;
        stealthActive    = !!stored.answerlyStealthActive;
        await renderMain();
        showView('view-main');
        return;
      }
    } catch {
      // Network error — allow offline use if token exists
      const payload = parseJwt(stored.answerlySession.token);
      if (payload && payload.exp * 1000 > Date.now()) {
        currentSession   = stored.answerlySession;
        quizActive       = !!stored.answerlyQuizActive;
        screenshotActive = !!stored.answerlyScreenshotActive;
        stealthActive    = !!stored.answerlyStealthActive;
        await renderMain();
        showView('view-main');
        return;
      }
    }
    // Token invalid — clear and show activation
    await chrome.storage.local.remove(['answerlySession', 'answerlyQuizActive', 'answerlyScreenshotActive', 'answerlyStealthActive']);
  }

  showView('view-activate');
}

function parseJwt(token) {
  try {
    return JSON.parse(atob(token.split('.')[1]));
  } catch { return null; }
}

// ── Render main view ──────────────────────────────────────────────────────────
async function renderMain() {
  profileCode.textContent   = currentSession.code;
  profileExpiry.textContent = 'Active until ' + formatDate(currentSession.expiresAt);

  renderToolBtn(btnQuizSolver, quizLabel, quizActive, 'QUIZ SOLVER');
  renderToolBtn(btnScreenshot, screenshotLabel, screenshotActive, 'SCREENSHOT TOOL');
  renderStealthBtn();

  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const url  = tabs[0]?.url || '';
  const isCanvas = /\/courses\/\d+\/(quizzes|assignments)/.test(url);
  notCanvasNotice.classList.toggle('hidden', isCanvas);
}

function renderToolBtn(btn, label, active, name) {
  btn.dataset.active = String(active);
  label.textContent  = active ? `DEACTIVATE ${name}` : `ACTIVATE ${name}`;
}

function renderStealthBtn() {
  btnStealth.classList.toggle('stealth-active', stealthActive);
  stealthEyeIcon.classList.toggle('hidden', stealthActive);
  stealthEyeSlashIcon.classList.toggle('hidden', !stealthActive);
}

// ── Activation ────────────────────────────────────────────────────────────────
// Auto-format code input as user types
codeInput.addEventListener('input', () => {
  const pos = codeInput.selectionStart;
  const raw  = codeInput.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
  const chunks = raw.match(/.{1,4}/g) || [];
  // Build formatted: ANS-XXXX-XXXX-XXXX
  let formatted = '';
  if (raw.length > 0) {
    const withoutPrefix = raw.startsWith('ANS') ? raw.slice(3) : raw;
    const parts = withoutPrefix.match(/.{1,4}/g) || [];
    formatted = 'ANS-' + parts.slice(0, 3).join('-');
  }
  codeInput.value = formatted;
});

codeInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') btnActivate.click();
});

btnActivate.addEventListener('click', async () => {
  const raw  = codeInput.value.trim();
  if (!raw) { showActivateError('Please enter your activation code.'); return; }

  activateError.classList.add('hidden');
  btnActivate.disabled = true;
  btnActivate.textContent = 'Activating…';

  try {
    const res  = await fetch(`${BACKEND_URL}/api/auth/activate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code: raw }),
    });
    const data = await res.json();

    if (!res.ok) {
      showActivateError(data.error || 'Activation failed.');
      return;
    }

    currentSession = { token: data.token, code: data.code, expiresAt: data.expiresAt };
    await chrome.storage.local.set({ answerlySession: currentSession });
    await renderMain();
    showView('view-main');
  } catch {
    showActivateError('Cannot reach server. Check your connection.');
  } finally {
    btnActivate.disabled = false;
    btnActivate.textContent = 'Activate';
  }
});

function showActivateError(msg) {
  activateError.textContent = msg;
  activateError.classList.remove('hidden');
}

btnBuy.addEventListener('click', () => {
  chrome.tabs.create({ url: 'https://buy.stripe.com/9B6aEP1Pi4CZ6CP17Y67S00' });
});

// ── Profile dropdown ──────────────────────────────────────────────────────────
btnProfile.addEventListener('click', (e) => {
  e.stopPropagation();
  menuDropdown.classList.add('hidden');
  profileDropdown.classList.toggle('hidden');
});

btnDeactivate.addEventListener('click', async () => {
  currentSession   = null;
  quizActive       = false;
  screenshotActive = false;
  stealthActive    = false;
  await chrome.storage.local.remove(['answerlySession','answerlyQuizActive','answerlyScreenshotActive','answerlyStealthActive']);
  profileDropdown.classList.add('hidden');
  codeInput.value = '';
  showView('view-activate');
});

// ── Menu dropdown ─────────────────────────────────────────────────────────────
btnMenu.addEventListener('click', (e) => {
  e.stopPropagation();
  profileDropdown.classList.add('hidden');
  menuDropdown.classList.toggle('hidden');
});

document.getElementById('menu-subscription').addEventListener('click', () => chrome.tabs.create({ url: 'https://buy.stripe.com/9B6aEP1Pi4CZ6CP17Y67S00' }));

document.getElementById('menu-manage').addEventListener('click', () => {
  chrome.tabs.create({ url: 'https://billing.stripe.com/p/login/9B6aEP1Pi4CZ6CP17Y67S00' });
});

document.addEventListener('click', () => {
  profileDropdown.classList.add('hidden');
  menuDropdown.classList.add('hidden');
});

btnClose.addEventListener('click', () => window.close());

// ── Script injection ──────────────────────────────────────────────────────────
async function injectScript(file) {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const tab  = tabs[0];
  if (!tab?.id) return;
  try {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: [file] });
  } catch (err) {
    console.warn('Answerly AI: injection failed', err.message);
  }
}

async function sendToActiveTab(message) {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const tab  = tabs[0];
  if (!tab?.id) return;
  try { await chrome.tabs.sendMessage(tab.id, message); } catch {}
}

// ── Tool toggles ──────────────────────────────────────────────────────────────
btnQuizSolver.addEventListener('click', async () => {
  quizActive = !quizActive;
  renderToolBtn(btnQuizSolver, quizLabel, quizActive, 'QUIZ SOLVER');
  await chrome.storage.local.set({ answerlyQuizActive: quizActive });
  if (quizActive) {
    await injectScript('content/quizSolver.js');
    await sendToActiveTab({ type: 'QUIZ_SOLVER_ON' });
  } else {
    await sendToActiveTab({ type: 'QUIZ_SOLVER_OFF' });
  }
});

btnScreenshot.addEventListener('click', async () => {
  screenshotActive = !screenshotActive;
  renderToolBtn(btnScreenshot, screenshotLabel, screenshotActive, 'SCREENSHOT TOOL');
  await chrome.storage.local.set({ answerlyScreenshotActive: screenshotActive });
  if (screenshotActive) {
    await injectScript('content/screenshotTool.js');
    await sendToActiveTab({ type: 'SCREENSHOT_TOOL_ON' });
  } else {
    await sendToActiveTab({ type: 'SCREENSHOT_TOOL_OFF' });
  }
});

// ── Stealth ───────────────────────────────────────────────────────────────────
btnStealth.addEventListener('click', async () => {
  stealthActive = !stealthActive;
  renderStealthBtn();
  await chrome.storage.local.set({ answerlyStealthActive: stealthActive });
  await sendToActiveTab({ type: stealthActive ? 'STEALTH_ON' : 'STEALTH_OFF' });
});

// ── Customize ─────────────────────────────────────────────────────────────────
document.getElementById('btn-customize').addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('popup/customize.html') });
});

// Also update content scripts to read from new session key
// background.js reads answerlySession — keep in sync
chrome.storage.local.get('answerlySession', (s) => {
  // Ensure background.js can read the token under the right key
});

init();
